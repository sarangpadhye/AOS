/**
 * @file future_set.c
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <future.h>
#include <thread.h>
#include <queue.h> 
#define MAX 10
int i=0,j=0,prodQueue1[10],testQueue1[10];
/**
 * Set value for the future
 * @param fut  target future
 * @param value value to be set for the future
 * @return OK on success, SYSERR on failure
 */
 
 void insert_element(int fut, int queue[], int *front ,int *rear)
{

		queue[*rear]=fut;
		prodQueue1[i] = queue[*rear];
		*rear = *rear + 1;
		i++;
 }	

syscall future_set(future fut, int value)
{
    register struct futent *futptr;
	irqmask im;
	
    im = disable();
    if (isbadfut(fut))
    {
        restore(im);
        return SYSERR;
    } 
	
	futptr = &futtab[fut];
	
	if(futptr->state == FUT_FREE)
	{ 
		restore(im);
		
		prodQueue1[0] = *futptr->prodQueue;		
			if(futtab[fut].ft_shared == 1) 
				{
				insert_element(value, prodQueue1, &futptr->prodFront, &futptr->prodRear);
				memcpy(futtab[fut].prodQueue, prodQueue1, sizeof(futtab[fut].prodQueue));
				}
			else if(futtab[fut].ft_shared == 0) 	
				{
				futtab[fut].data=value;					
				}
				
	}
		
	if(futptr->state == FUT_USED)
	{
		futptr->data=value;
		futptr->state = FUT_USED;
		if(futptr->flag == 1)
		ready(futptr->tid, RESCHED_YES);
	}	
	
	restore(im);
	return OK;
	   
}
