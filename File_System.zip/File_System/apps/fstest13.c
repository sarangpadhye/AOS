struct directory d;
struct filetable ft[128];

int fcount; //keeps track of the count of number of files in file table

int icount=1; 	//count to keep track of the inodes created



/****************************************************************************************
						Function name : fopen()
						Return type    : Returns a file descriptor
						Purpose        : Open a file and update open file table 
*****************************************************************************************/
	

	
	
int fopen(char *filename, int flags)
{
	int i;
	
	int inum;
	int iflag=0;
		
	for(i=0;i<d.numentries;i++)
	{
		if(strcmp(filename,d.entry[i].name) == 0)
		{
			inum=inode_num;
			iflag=i;
		}
	}
			
	if(iflag!=0)
	{
		printf("File not present\n");
		return SYSERR;
	}
	
	
	ft[fcount].state=1;
	ft[fcount].fileptr=((inum%4)*128);
	ft[fcount].in=inum;
	ft[fcount].de=&d.entry[iflag];
	
	fcount++;
	
	return fcount-1;
	
}

/****************************************************************************************
						Function name : fread()
						Return type    : returns the number of byte
						Purpose        : read nbytes from the buffer using bread 
*****************************************************************************************/



int fread(int fd, void *buf, int nbytes)
{

	int i;
	int inum;
	if(ft[fd].state == 0)
	{
		printf("Cannot Read: File not open in read mode\n");
		return SYSERR;
	}
	
	inum=ft[fd].in.id;
	for(i=0; i<nbytes/128; i++)
	{
		 bread(0, (ft[fd].in.blocks[inum%4]),i*(inum%4)*128 , buf, nbytes); 
	
	}
	
	return nbytes;
	
}

/****************************************************************************************
						Function name : fcreate()
						Return type    : Returns if file creation is successfull or not
						Purpose        : Create a file and assign a inode
*****************************************************************************************/


int fcreate(char *filename, int mode)
{
	struct inode in;
	struct dirent de;
	//create inode entries for the file created
	in.id=icount++;
	in.type=1;
	in.device=0;
	in.size=0;
	
	/* write the inode block and mark block used */
	setmaskbit(in.id/4);
	bwrite(dev0, in.id/4, ((in.id%4)*128), &in, sizeof(struct inode));

	
	//creating directory entries for the file created
	de.inode_num=in.id;
	strcpy(filename, de.name);
	
	if(d.numentries > DIRECTORY_SIZE)
	{
		printf("Directory full: No of files cannot be greater than DIRECTORY_SIZE\n");
		return SYSERR;
	}
	
	d.entry[numentries]=de;
	d.numentries++;
	return 1;

}
/****************************************************************************************
						Function name : fwrite()
						Return type    : Returns nbytes which are written successfully
						Purpose        : Write text in blocks using bwrite
*****************************************************************************************/

int fwrite(int fd, void *buf, int nbytes)
{	
	int i;
	int inum;
	if(ft[fd].state == 0)
	{
		printf("Cannot write: File not open in write mode\n");
		return SYSERR;
	}
	
	inum=ft[fd].in.id;
	for(i=0; i<nbytes/128; i++)
	{
		 bwrite(0, (ft[fd].in.blocks[inum%4]),i*(inum%4)*128 , buf, nbytes); 
	
	}
	
	return nbytes;
}



/****************************************************************************************
						Function name : fseek()
						Return type    : int
						Purpose        : Returns the position in the file.
*****************************************************************************************/


int fseek(int fd, int offset)
{
	if(ft[fd])
	{
		return ft[fd].fileptr+=offset;	
	}
	return SYSERR;
}

/****************************************************************************************
						Function name : fclose()
						Return type    : int
						Purpose        : close the file using the file descriptor
*****************************************************************************************/



int fclose(int fd)
{
	ft[fd].state=0; // file closed
}