#ifndef _FUTURE_H_
#define _FUTURE_H_
#include <queue.h>
#define FUT_FREE 0
#define FUT_USED 1
#define NFUTURE 50

typedef unsigned int future;

struct futent           /*future table entry*/
{
	int data;		 	/*The data that future should hold*/
	char state;      	/*state of the future which can be FUT_FREE or FUT_USED*/
	int flag;		 	/*flag to check if a process is waiting for the future*/
	int tid;		 	/*process id waiting for the future*/	
	int ft_shared;   	/* to check if a future is shared or not*/
	int ft_queue;    	/* flag to enqueue and dequeue*/
	int prodRear;    	/* Rear pointer to the producer queue */
	int prodFront;   	/* Front pointer to the producer queue */
	int consRear;	 	/* Rear pointer to the Consumer queue */	
	int consFront;   	/* Front pointer to the Consumer queue */ 
	int prodQueue[10];  /* Pointer to the producer queue */
	int consQueue[10];  /* Pointer to the Consumer queue */
};

extern struct futent futtab[];
#define isbadfut(f) (f >= NFUTURE)
void testfuture(void);
syscall future_set(future, int);
void insert_element(int, int [], int *, int *);
int delete_element(int [], int *, int *);
future futalloc(int);

#endif
