#include <stdio.h>
#include <prod13.h>
#include <semaphore.h>

void consume(int,int);
void produce(int,int);

int n = 0; /* external variables are shared by all processes */

/*------------------------------------------------------------------------
 * * prod13p -- example of synchronized producer and consumer processes using semaphores
 * we have declared two semaphores and we are using 'semcreate' to initialize the semaphores.
 * After the two proccesses are run, we are deleting the semaphores using 'semfree'
 * *------------------------------------------------------------------------
 * */
void prod13p()
{
int consumed,produced;

consumed = semcreate(0);
produced = semcreate(1);

resume( create(consume, 1024, 20, "cons", 2, consumed, produced) );
resume( create(produce, 1024, 20, "prod", 2, consumed, produced) );

}
/*------------------------------------------------------------------------
 * * produce -- increment n 40 times and exit
 * The producer is waiting on the consumer before incrementing n
 * *------------------------------------------------------------------------
 * */
void produce(int consumed, int produced)
{

int i;
for( i=1 ; i<=40; i++ )
{
wait(consumed);
n++;
signal(produced);
}

semfree(produced);
}
/*------------------------------------------------------------------------
 * * consume -- print n 80 times and exit
 * The consumer is waiting on the producer before printing the value of n
 * *------------------------------------------------------------------------
 * */
void consume(int consumed, int produced)
{
int i;
for( i=1 ; i<=40; i++ )
{
wait(produced);
printf("\n The value of n is %d \r", n);
signal(consumed);
}
semfree(consumed);
}
