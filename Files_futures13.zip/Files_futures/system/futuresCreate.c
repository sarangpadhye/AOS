#include <future.h>
#include <interrupt.h>
#include <stdio.h>

future futalloc(void)
{

	int futures =0;
	static int nextfut = 0;
	
	for(futures =0;futures <NFUTURE;futures ++)
	{
		nextfut = (nextfut+1)%NFUTURE;
		if(FUT_FREE == futtab[nextfut].state)
		{
			futtab[nextfut].state = FUT_FREE;
			return nextfut;
		}
	}
	return SYSERR;
}
						
