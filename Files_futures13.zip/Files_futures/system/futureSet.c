/**
 * @file future_set.c
 *
 */

#include <future.h>
#include <thread.h>
#include <queue.h>
/**
 * Set value for the future
 * @param fut  target future
 * @param value value to be set for the future
 * @return OK on success, SYSERR on failure
 */
syscall future_set(future fut, int value)
{
    register struct futent *futptr;
	irqmask im;
	
    im = disable();
    if (isbadfut(fut))
    {
        restore(im);
        return SYSERR;
    } 
	
	futptr = &futtab[fut];
	
	if(futptr->state == FUT_USED)
	{
		restore(im);
		return SYSERR;
	}
	if(futptr->state == FUT_FREE)
	{
		futptr->data=value;

		futptr->state = FUT_USED;
		if(futptr->flag == 1)
		ready(futptr->tid, RESCHED_YES);
	}
		
	restore(im);
	return OK;
	   
}
