*******************************************************************************************************************************************************
Assignment 2 : Write a C program for a synchronised producer consumer using semaphores in XINU
*******************************************************************************************************************************************************

Files included with this project :
-----------------------------------
1) prod13p.c     - This file contains the actual code for the synchronised producer and consumerusing the semaphores.
2) xsh_prod13.c  - This file is responsible for calling the function prod13p().
3) prod13.h      - This is the header file in which the prototype for the function prod13p() is defined and included in both the above files mentioned


Existing Files in which changes needed to be done:
----------------------------------------------------
1) /xinu-arm/apps/Makerules  - Add prod13p.c
2) /xinu-arm/shell/Makerules - Add xsh_prod13.c
3) /xinu-arm/shell/shell.c   - Add the command name(prod13) and xsh_prod13.c

Colloborators :
-----------------------------------
1) This project is colloborated between Sarang Padhye and Pranam acharya for whom node 13 has been assigned.

2) In this colloboration I was responsible to implement the consumer part of the code along with semfree() while my team mate implemented the producer part.We tested
   the code together.

Description :
-----------------------------------
1) In the previous assignment we had implemented the producer and consumer problem in an unsynchronised fashion. In this assignment though we have implemented the producer
consumer problem with synchronisation using the semaphores.

2) In order to implement semaphores we have used the function semcreate() which is a inbuilt function. We then have written 2 functions produced() and consumed() in which
we have implemented wait() and signal() which are system calls.

Observations and results
-----------------------------------
1) In order to run this program follow the below instructions:
	- Copy the file prod13p.c in to /xinu-arm/apps/
	- Copy the file xsh_prod13.c in to /xinu-arm/shell/
	- Copy the file prod13.h in to /xinu-arm/include/
	- Make respective changes in directories shell,apps.
	- In directory compile ,run "make && make download"
	- Access the xinu screen and run the command "prod13"

2) After running the code it is observed that all the values of the shared variable are printed as against the unsynchronised producer and consumer depicting the
   attainment of synchronisation.

References
---------------

1) Dougles Comer , Operating System design : The XINU Approach.

