#ifndef _FUTURE_H_
#define _FUTURE_H_

#include <queue.h>

//states for the future

#define FUT_FREE 0
#define FUT_USED 1

#define NFUTURE 50
typedef unsigned int future;


struct futent           /*future table entry*/
{
	int data;		/* The data that future should hold */
	char state;     	/*state of the future which can be FUT_FREE or FUT_USED*/
	int flag;		/*flag to check if a process is waiting for the future*/
	int tid;		/*process id waiting for the future*/	
};


extern struct futent futtab[];
#define isbadfut(f) (f >= NFUTURE)
void testfuture(void);
future futalloc(void);


#endif
