#include <stdio.h>
#include <future.h>

void producer(future,int);
void consumer(future);
	
void testfuture(void)
{
	int x = 13;
	int y = 23;
	int z = 39;		
	int z1 = 52;
	
	future f1,f2,f3;

	f1=futalloc(1);
	f2=futalloc(0);
	f2=futalloc(2);
 	
	resume(create(producer,1024,30,"producer1",2,f1,x));
	resume(create(producer,1024,30,"producer2",2,f1,y));
	resume(create(producer,1024,30,"producer4",2,f1,z));
		
	resume(create(consumer,1024,30,"consumer7",1,f1));
	resume(create(consumer,1024,30,"consumer8",1,f1));
	resume(create(consumer,1024,30,"consumer9",1,f1));			

	resume(create(producer,1024,30,"producer5",2,f2,z1));
	resume(create(consumer,1024,30,"consumer16",1,f2));    
}

void producer(future f1, int setVal)
{	
	future_set(f1,setVal);
	printf("\n \rIn Producer : The value is %d\n \r",setVal);	
}

void consumer(future f)
{	
	int val;
	if(future_get(f,&val)==OK)
	{
		printf("\n \rIn Consumer : The value is %d\n \r",val);			
	}
}



