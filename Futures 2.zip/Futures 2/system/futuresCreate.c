#include <future.h>
#include <interrupt.h>
#include <stdio.h>

future futalloc(int ft_shared)
{

	int futures =0;
	static int nextfut = 0;
	
	for(futures =0;futures <NFUTURE;futures++)
	{
		nextfut = (nextfut+1)%NFUTURE;
		if(FUT_FREE == futtab[nextfut].state)
		{
			futtab[nextfut].state = FUT_FREE;
			futtab[nextfut].ft_shared = ft_shared;
			return nextfut;
		}
	}
	
	return SYSERR;
}
						
