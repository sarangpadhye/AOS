#include <stdio.h>
#include <future.h>


void producer(future,int);
void consumer(future);
	
void testfuture(void)
{
	int x = 13;
	int y =26;
	int z =39;

	future f1,f2,f3;

	f1=futalloc();
	f2=futalloc();
	//f3=futalloc();
    		
	resume(create(consumer,1024,30,"consumer1",1,f1));	
	resume(create(consumer,1024,30,"consumer2",1,f2));	
	resume(create(consumer,1024,30,"consumer3",1,f1));	
	
	resume(create(producer,1024,30,"produder1",2,f1,x));
	resume(create(producer,1024,30,"produder2",2,f2,y));
	//resume(create(producer,1024,30,"produder3",2,f2,z));
    
	
}

void consumer(future f)
{
	int val;
	if(future_get(f,&val)==OK)
	{
		printf("\n \rIn Consumer : The value is %d\n \r",val);	
		free(f);
	}
}

void producer(future f1, int setVal)
{	
	future_set(f1,setVal);	
}

