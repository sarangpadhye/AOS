/**
 * @file future_get.c
 * 
 *
 * 
 */

#include <future.h>
#include <thread.h>
#include <queue.h>
/**
 * Make current process wait on the future if the value for the future is not set
 * get value of the future
 * @param fut  future variable
 * @param value future value to be returned for the consumer 
 * @return OK on success, SYSERR on failure 
 */
syscall future_get(future fut, int *value)
{
	register struct futent *futptr;
    register struct thrent *thrptr;
    irqmask im;
	
	im = disable();
    if (isbadfut(fut))
    {
        restore(im);
        return SYSERR;
    }
	
	thrptr = &thrtab[thrcurrent];
	futptr = &futtab[fut];
		
	if(futptr->flag == 1)
	{
		restore(im);
		printf("\n \rTrying to access blocked future: Process %s blocked\n\r",thrptr->name);
		return SYSERR;
	}	
	
	if(futtab[fut].state == FUT_FREE)
	{
		futptr->flag=1;
		thrptr->state = THRWAIT;
       	printf("\n \r Process Waiting \n \r");
		thrptr->fut = fut;
		futptr->tid=thrcurrent;
	   	resched();
	}
	
	
	//printf("\n \rprocess name is -- %s  and the value retrieved is %d \n \r",thrptr->name,futptr->data);
	*value=futtab[fut].data;
	
	restore(im);
	return OK;
}
