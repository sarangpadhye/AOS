/**
 * @file future_get.c

 */
#include <stdio.h>
#include <stdlib.h>
#include <future.h>
#include <thread.h>
#include <queue.h>
#define MAX 15
 int consQueue1 [10],a=0,b=0,c=0,deleted; 
 
/**
 * Make current process wait on the future if the value for the future is not set
 * get value of the future
 * @param fut  future variable
 * @param value future value to be returned for the consumer 
 * @return OK on success, SYSERR on failure 
 */
  
 int delete_element(int queue[], int *front, int *rear)
{
		int element;
		element=queue[*front];
		if(queue[*front] == 0)
		{
		*front = *front - 1;
		element = queue[*front];		
		}
		else
		{
		element = queue[*front];
		*front= *front + 1; 
		}
	    return element; 
}

syscall future_get(future fut, int *value)
{
	register struct futent *futptr;
    register struct thrent *thrptr;
	thrptr = &thrtab[thrcurrent];
	futptr = &futtab[fut];
	
    irqmask im;
	
	im = disable();
    if (isbadfut(fut))
    {
        restore(im);
		printf( " returning error \n \r " );
        return SYSERR;
    }

	if(futtab[fut].state == FUT_USED)
	{
		futptr->flag=1;
		thrptr->state = THRWAIT;
    	thrptr->fut = fut;
		futptr->tid=thrcurrent;
	   	resched();
	}
	if(futtab[fut].state == FUT_FREE)
	{
		restore(im);
		//*futptr->consQueue =thrcurrent;
			if(futtab[fut].ft_shared == 1 ) 
				{	
				memcpy(consQueue1, futptr->prodQueue, sizeof(consQueue1));	
				deleted = delete_element(consQueue1,&futptr->prodFront, &futptr->prodRear);		
				*value= deleted;
				}
			else 
				{		
				free(futptr);		
				futptr = &futtab[fut];		
				*value=futtab[fut].data;	
				}
				//futtab[fut].state = FUT_USED;
	}		
	restore(im);
	return OK;
}
