#include <stddef.h>
#include <stdio.h>
#include <future.h>


shellcmd xsh_futures13(int nargs,char *args[])
{
	testfuture();

}
